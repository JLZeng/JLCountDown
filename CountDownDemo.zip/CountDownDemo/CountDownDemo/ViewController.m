//
//  ViewController.m
//  CountDownDemo
//
//  Created by Jialun Zeng on 2017/5/12.
//  Copyright © 2017年 com.zjl.countDown. All rights reserved.
//

#import "ViewController.h"
#import "ViewController1.h"
#import "ViewController2.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 200, self.view.frame.size.width - 200, 40);
    btn.backgroundColor = [UIColor blackColor];
    [btn setTitle:@"倒计时1" forState:UIControlStateNormal];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(countDown1) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1.frame = CGRectMake(100, CGRectGetMaxY(btn.frame) + 100, self.view.frame.size.width - 200, 40);
    btn1.backgroundColor = [UIColor blackColor];
    [btn1 setTitle:@"倒计时2" forState:UIControlStateNormal];
    [self.view addSubview:btn1];
    [btn1 addTarget:self action:@selector(countDown2) forControlEvents:UIControlEventTouchUpInside];
    

    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)countDown1{
    ViewController1 * vc = [[ViewController1 alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)countDown2{
    ViewController2 * vc = [[ViewController2 alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
