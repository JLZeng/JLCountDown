//
//  ViewController2.m
//  CountDownDemo
//
//  Created by Jialun Zeng on 2017/5/12.
//  Copyright © 2017年 com.zjl.countDown. All rights reserved.
//

#import "ViewController2.h"
#import "JLCountDown.h"
@interface ViewController2 ()

@property(nonatomic,strong)UIButton * btn;

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.btn = [UIButton buttonWithType:UIButtonTypeCustom];
    self.btn.frame = CGRectMake(100, 200, self.view.frame.size.width - 200, 40);
    self.btn.backgroundColor = [UIColor blackColor];
    [self.btn setTitle:@"开始倒计时" forState:UIControlStateNormal];
    [self.view addSubview:self.btn];
    [self.btn addTarget:self action:@selector(startCountDown) forControlEvents:UIControlEventTouchUpInside];
    
    [self initCountDown];
    // Do any additional setup after loading the view.
}

-(void)initCountDown{
    __block UIButton * btn = self.btn;
    [[JLCountDown sharedManager]setCountDownWithDuration:60
                                           countDownName:NSStringFromClass([self class])
                                            countDowning:^(NSInteger time)
     {
         btn.enabled = NO;
         [btn setTitle:[NSString stringWithFormat:@"%ld",(long)time] forState:UIControlStateNormal];
     } finished:^{
         btn.enabled = YES;
         [btn setTitle:@"重新开始" forState:UIControlStateNormal];
     }];
}

-(void)startCountDown{
    [[JLCountDown sharedManager]startWithCountDownName:NSStringFromClass([self class])];
}

-(void)dealloc
{
    [[JLCountDown sharedManager]removeDaoJiShiWithCountDownName:NSStringFromClass([self class])];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
