//
//  JLCountDownManager.h
//  zjl
//
//  Created by Jialun Zeng on 2017/4/27.
//  Copyright © 2017年 com.sgcai.maibeng. All rights reserved.
//

#import <Foundation/Foundation.h>
@class JLTimer;

typedef void(^JLCountDowning) (NSInteger time);
typedef void(^JLCountDowned) ();

@interface JLCountDown : NSObject

+(instancetype)sharedManager;

/**
 需要通过此方法先加进来，再调用startWithCountDownName才会开始计时

 @param duration 总时长
 @param countDownName 用来标识是哪个类活功能的计时器
 @param countDowningBlock 正在倒计时回调
 @param countDownedBlock 倒计时结束回调
 */
-(void)setCountDownWithDuration:(NSInteger)duration
                  countDownName:(NSString *)countDownName
                   countDowning:(JLCountDowning)countDowningBlock
                       finished:(JLCountDowned)countDownedBlock;

//根据countDownName开始计时器
-(void)startWithCountDownName:(NSString *)countDownName;
//根据countDownName移除计时器
-(void)removeDaoJiShiWithCountDownName:(NSString *)countDownName;

@end


@protocol JLTimerDelegate <NSObject>

-(void)finishedOfTimer:(JLTimer *)timer countDownName:(NSString *)countDownName;

@end

@interface JLTimer : NSObject

@property (nonatomic ,copy) JLCountDowning countDowningBlock;
@property (nonatomic ,copy) JLCountDowned countDownedBlock;
@property (nonatomic ,assign) NSInteger duration;
@property (nonatomic ,assign) BOOL countDowning;
@property (nonatomic ,strong) NSString * countDownName;
@property (nonatomic ,assign) NSInteger currentSeconds;
@property (nonatomic ,weak) id <JLTimerDelegate>delegate;

- (instancetype)initWithTarget:(id<JLTimerDelegate>)target
                      Duration:(NSInteger)duration
                 countDownName:(NSString *)countDownName
                  countDowning:(JLCountDowning)countDowningBlock
                      finished:(JLCountDowned)countDownedBlock;

-(void)start;

@end
