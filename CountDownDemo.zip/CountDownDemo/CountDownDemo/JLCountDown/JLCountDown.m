//
//  JLCountDownManager.m
//  zjl
//
//  Created by Jialun Zeng on 2017/4/27.
//  Copyright © 2017年 com.sgcai.maibeng. All rights reserved.
//

#import "JLCountDown.h"

@interface JLCountDown ()<JLTimerDelegate>

@property (nonatomic ,strong) NSMutableDictionary * dict;
@property (nonatomic ,strong) NSMutableSet *  preRemove ;//预移除的计时器key

@end

@implementation JLCountDown

+(instancetype)sharedManager{
    return [[self alloc] init];
}

- (id)copyWithZone:(NSZone *)zone{
    return self;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [super allocWithZone:zone];
    });
    return instance;
}


-(NSMutableSet *)preRemove{
    if (!_preRemove) {
        _preRemove = [[NSMutableSet alloc]init];
    }
    return _preRemove;
}

-(NSMutableDictionary *)dict{
    if (!_dict) {
        _dict = [[NSMutableDictionary alloc]init];
    }
    return _dict;
}

-(void)setCountDownWithDuration:(NSInteger)duration
                  countDownName:(NSString *)countDownName
                   countDowning:(JLCountDowning)countDowningBlock
                       finished:(JLCountDowned)countDownedBlock
{
    //如果计时器已存在字典中 则直接用
    if ([self.dict objectForKey:countDownName]) {
        JLTimer * timer = [self.dict objectForKey:countDownName];
        timer.countDownedBlock = countDownedBlock;
        timer.countDowningBlock = countDowningBlock;
        
        //如果当前要用的计时器在预删除数组中存在，则移除预删除数组中的项
        if ([self.preRemove containsObject:countDownName]) {
            [self.preRemove removeObject:countDownName];
        }
        
        //如果存在直接返回一个时间
        if (timer.currentSeconds) {
            countDowningBlock(timer.currentSeconds);
        }else{
            countDownedBlock(0);
        }
    }else{
        //不存在于字典中的则初始化
        JLTimer * timer = [[JLTimer alloc]initWithTarget:self
                                                Duration:duration
                                           countDownName:countDownName
                                            countDowning:countDowningBlock
                                                finished:countDownedBlock];
        
        [self.dict setObject:timer forKey:countDownName];
    }
}



-(void)startWithCountDownName:(NSString *)countDownName{
    JLTimer * timer = [self.dict objectForKey:countDownName];
    [timer start];
}


-(void)removeDaoJiShiWithCountDownName:(NSString *)countDownName{
    JLTimer * timer = [self.dict objectForKey:countDownName];
    if (timer) {
        if (timer.countDowning) {
            [self.preRemove addObject:countDownName];
        }else{
            [self.dict removeObjectForKey:countDownName];
        }
    }
}

//当有一个timer结束时，删除timer对象
-(void)finishedOfTimer:(JLTimer *)timer countDownName:(NSString *)countDownName{
    if ([self.preRemove containsObject:countDownName]) {
        if ([self.dict objectForKey:countDownName]) {
            [self.dict removeObjectForKey:countDownName];
        }
    }
}

@end



@implementation JLTimer

- (instancetype)initWithTarget:(id<JLTimerDelegate>)target
                      Duration:(NSInteger)duration
                 countDownName:(NSString *)countDownName
                  countDowning:(JLCountDowning)countDowningBlock
                      finished:(JLCountDowned)countDownedBlock
{
    self = [super init];
    if (self) {
        self.duration = duration;
        self.countDowningBlock = countDowningBlock;
        self.countDownedBlock = countDownedBlock;
        self.countDownName = countDownName;
        self.delegate = target;
    }
    return self;
}

-(void)start{
    
    if (self.countDowning)return;
    
    __block NSInteger time = self.duration - 1;
    __weak typeof(self)weakSelf = self;
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0);
    dispatch_source_set_event_handler(_timer, ^{
        
        if(time <= 0){
            weakSelf.currentSeconds = time;
            dispatch_source_cancel(_timer);
            weakSelf.countDowning = NO;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (weakSelf.countDownedBlock) {
                    weakSelf.countDownedBlock(0);
                }
                if ([weakSelf.delegate respondsToSelector:@selector(finishedOfTimer:countDownName:)]) {
                    [weakSelf.delegate finishedOfTimer:weakSelf countDownName:self.countDownName];
                }
            });
        }else{
            NSInteger seconds = time % weakSelf.duration;
            weakSelf.currentSeconds = seconds;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (weakSelf.countDowningBlock) {
                    weakSelf.countDowningBlock(seconds);
                }
            });
            
            time--;
        }
    });
    
    dispatch_resume(_timer);
    self.countDowning = YES;
}


@end

